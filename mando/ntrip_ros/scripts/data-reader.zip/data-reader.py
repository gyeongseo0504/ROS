
import sys
print(sys.getdefaultencoding())
import os
import rospy
from rtcm_msgs.msg import Message
from std_msgs.msg import String
fifo_name = "my_pipe"

data_old = b'\x41'


def rtcm_client_pub():
	global data_old
	buf =""
	rmsg = Message()
	pub = rospy.Publisher('/gps/rtcm', Message, queue_size=10)
	rospy.init_node('ros_ntrip_kkw', anonymous=True)
	rate = rospy.Rate(10) # 10hz
	
	while not rospy.is_shutdown():
		with open(fifo_name, "rb") as pipe:
			data = pipe.read()
			
			#print(type(data))
			if(data != data_old):
				print('received:',data)
		
				for i in data:
					#print(i)
					buf =+i
				rmsg.message = buf
				rmsg.header.seq += 1
				rmsg.header.stamp = rospy.get_rostime()               
				pub.publish(rmsg)
				buf = ""
			data_old = data
		 
		 
		rate.sleep()
 
        
        
        
if __name__ == '__main__':
	try:
		rtcm_client_pub()
	except rospy.ROSInterruptException:
		pass
