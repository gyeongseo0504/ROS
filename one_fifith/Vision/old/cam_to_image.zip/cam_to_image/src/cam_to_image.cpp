//opencv_line_detect.cpp
//-I/usr/local/include/opencv4/opencv -I/usr/local/include/opencv4

#include <ros/ros.h>
#include "std_msgs/String.h"
#include "std_msgs/Int16.h"
#include "std_msgs/Bool.h"
#include "image_transport/image_transport.h"
#include "cv_bridge/cv_bridge.h"
#include "sensor_msgs/Image.h"

#include <opencv2/opencv.hpp>
#include <iostream>
#include <stdio.h> 
#include <string.h> 
#include <stdio.h>
#include <unistd.h>   
#include <stdint.h>   
#include <stdlib.h>  
#include <errno.h>

using namespace cv;
using namespace std;

#define IMG_Width     800
#define IMG_Height    600

#define USE_DEBUG  1   // 1 Debug  사용
#define USE_CAMERA 1   // 1 CAMERA 사용  0 CAMERA 미사용


Mat mat_image_org_color;  // Image 저장하기 위한 변수
Mat mat_image_org_gray;
Mat mat_image_roi;
Mat mat_image_canny_edge;
Mat mat_image_canny_edge_roi;

Scalar GREEN(0,255,0);
Scalar RED(0,0,255);
Scalar BLUE(255,0,0);
Scalar YELLOW(0,255,255);


int img_width  = IMG_Width ;
int img_height = IMG_Height;

bool capture_flag = false;

void capture_flagCallback(const std_msgs::Bool::ConstPtr& cap_flag)
{
	capture_flag  = cap_flag->data;
}



int main(int argc, char **argv)
{
	int i;
	int steer_angle_new, steer_angle_old;
   
   
	int capture_width = 1280 ;
	int capture_height = 720 ;
	int display_width = 640 ;
	int display_height = 360 ;
	int framerate = 60 ;
	
	int img_width  = 1280;
	int img_height = 7200;
	  
   
    int CamNum = 0;                            //camera number
    cv::VideoCapture cap(CamNum);
    cap.set(3,1280);
    cap.set(4,720);
   // return 1;
	ros::init(argc, argv, "cam_to_image");

  /**
   * NodeHandle is the main access point to communications with the ROS system.
   * The first NodeHandle constructed will fully initialize this node, and the last
   * NodeHandle destructed will close down the node.
   */
	ros::NodeHandle nh;
	
	image_transport::ImageTransport it(nh);
    image_transport::Publisher video_img_pub  = it.advertise("usb_cam/image_raw", 5);    // image publish
    
    ros::Subscriber sub_capture_flag           = nh.subscribe("usb_cam/capture_flag", 1, capture_flagCallback);
    
	std::cout << "OpenCV version : " << CV_VERSION << std::endl;
	
	
	if (!cap.isOpened())
	{
		printf("Camera ins not opened");
		return -1;
	}
    else
    {  
		printf("Camera Open success!\n\n\n");
		
	}
	
	sensor_msgs::ImagePtr img_msg; 
	 
	ros::Rate loop_rate(15);
	int count = 0;
   
	namedWindow("Video Image", WINDOW_NORMAL);
	resizeWindow("Video Image", IMG_Width/2,IMG_Height/2);
	moveWindow("Video Image", 10, 10); 
   
   
    
   while (ros::ok())
   { 
    /**
     * This is a message object. You stuff it with data, and then publish it.
     */
		//sensor_msgs::ImageConstPtr image_topic_ptr;
		//image_topic_ptr  = ros::topic::waitForMessage<sensor_msgs::Image>("/usb_cam/image_raw",nh,ros::Duration(2) )  ;
		if(capture_flag  == true)
		{
			
			cap >> mat_image_org_color;
		
			img_msg = cv_bridge::CvImage(std_msgs::Header(), "bgr8", mat_image_org_color).toImageMsg();
			
			img_width  = mat_image_org_color.size().width;
			img_height = mat_image_org_color.size().height;
        
			printf("width : %d  height : %d  %d\n",img_width,img_height,count);
         
			video_img_pub.publish(img_msg);  
           
			if(!mat_image_org_color.empty())	   imshow("Video Image", mat_image_org_color);
			else 
			{
				
				destroyWindow("Video Image");
				return -1;
				
			}
		   
			if (waitKey(25) >= 0)
				break;
        }
        else
        {
			printf("waiting for capture\n\n");
			
		}
	ros::spinOnce();

	loop_rate.sleep();
	++count;
  }

  destroyWindow("Video Image");
  //destroyWindow("Gray Image window");
  //destroyWindow("ROI Image window");
  //destroyWindow("Edge Image window");
   return 0;
}

 
