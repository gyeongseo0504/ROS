#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/Image.h>
#include <opencv2/opencv.hpp>

cv::Mat cv_image;

int img_width;
int img_height;


void CamImageCallback(const sensor_msgs::Image::ConstPtr& msg)
{
    cv_image = cv_bridge::toCvShare(msg,"bgr8")->image;
    img_width = cv_image.size().width;
    img_height = cv_image.size().height;
	
	cv::imshow("test", cv_image);
	cv::waitKey(1);
}

int main(int argc, char **argv)
{

	
	ros::init(argc, argv, "ros_cv_image_view");
	
	ros::NodeHandle nh;
    
    ros::Subscriber ai_image_sub = nh.subscribe("/usb_cam/image_raw",5,&CamImageCallback);
	ros::Rate loop_rate(30.0); //30.0HZ

	ros::spin();
	cv::destroyWindow("test");
	/*
	while(ros::ok())
	{
		loop_rate.sleep();
		ros::spinOnce();
	}*/
}
