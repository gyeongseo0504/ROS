#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/Image.h>
#include <opencv2/opencv.hpp>
#include "std_msgs/Bool.h"

cv::Mat cv_image;

int img_width;
int img_height;

/*
void CamImageCallback(const sensor_msgs::Image::ConstPtr& msg)
{
    cv_image = cv_bridge::toCvShare(msg,"bgr8")->image;
    img_width = cv_image.size().width;
    img_height = cv_image.size().height;
    
    printf("width : %d  height : %d \n",img_width,img_height);
}
*/
int main(int argc, char **argv)
{

	ros::init(argc, argv, "ros_hailo_ai_image");
	
	ros::NodeHandle nh;
    
   // ros::Subscriber cam_image_sub       = nh.subscribe("/usb_cam/image_raw",1,&CamImageCallback);
	
	std_msgs::Bool test_bool_topic;
	
	ros::Rate loop_rate(30.0); //10.0HZ
	
	while(ros::ok())
	{
			
			sensor_msgs::ImageConstPtr image_topic_ptr;
			image_topic_ptr  = ros::topic::waitForMessage<sensor_msgs::Image>("Car_Control_cmd/image",nh,ros::Duration(2) )  ;
			
			//ROS_INFO("image topic get");
			if(image_topic_ptr == NULL)
			{
				ROS_WARN("NO Image Topic");
			}
			else
			{
				
				cv_image = cv_bridge::toCvShare(image_topic_ptr,"bgr8")->image;
				
				img_width = cv_image.size().width;
				img_height = cv_image.size().height;
    
                
                cv::imshow("test",cv_image);
                cv::waitKey(1);
				printf("width : %d  height : %d \n",img_width,img_height);
				
			}
			/*
			std_msgs::BoolConstPtr test; 
			test = ros::topic::waitForMessage<std_msgs::Bool>("/test_topic",nh,ros::Duration(2) ) ;
			
			
			if(test == NULL)
			{
				ROS_WARN("NO Topic");
			}
			else
			{
				test_bool_topic = *test;
				ROS_INFO(" test bool topic %d",test_bool_topic.data);
			}
			*/
			
		loop_rate.sleep();
		ros::spinOnce();
	}
}
