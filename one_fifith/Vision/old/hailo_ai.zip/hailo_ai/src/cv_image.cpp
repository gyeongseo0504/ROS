#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/Image.h>
#include <opencv2/opencv.hpp>

cv::Mat cv_image_in;
cv::Mat cv_image_out;

int img_width;
int img_height;

int org_img_width    = 640 ;
int org_img_height   = 480 ;


void CamImageCallback(const sensor_msgs::Image::ConstPtr& msg)
{
    cv_image_in = cv_bridge::toCvShare(msg,"bgr8")->image;
    img_width = cv_image_in.size().width;
    img_height = cv_image_in.size().height;
    
    if(!cv_image_in.empty())
    {
		cv::resize(cv_image_in, cv_image_out, cv::Size(org_img_width, org_img_height), 1);
		cv::imshow("Result Image", cv_image_out);
		cv::waitKey(1);	
	}
	
	printf("%3d %3d\n", img_width, img_height);
	
}

int main(int argc, char **argv)
{
	//char *argv[] = {"rosrun","hailo_ai","hailo_ai_view_node"};
    //int argc=3;
	
	ros::init(argc, argv, "ros_hailo_ai_view");
	
	ros::NodeHandle nh;
    
    ros::Subscriber ai_image_sub = nh.subscribe("ai/result_image",1,&CamImageCallback);
	ros::Rate loop_rate(30.0); //30.0HZ

	cv::namedWindow("Result Image", cv::WINDOW_NORMAL);
	cv::resizeWindow("Result Image", org_img_width/2,org_img_height/2);
	//cv::moveWindow("Result Image", 10, 10); 
	//ros::spin();
	
	
	while(ros::ok())
	{
		loop_rate.sleep();
		ros::spinOnce();
	}
	
	cv::destroyWindow("test");
}
