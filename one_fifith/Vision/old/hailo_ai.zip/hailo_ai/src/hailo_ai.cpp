/**
 * Copyright 2020 (C) Hailo Technologies Ltd.
 * All rights reserved.
 *
 * Hailo Technologies Ltd. ("Hailo") disclaims any warranties, including, but not limited to,
 * the implied warranties of merchantability and fitness for a particular purpose.
 * This software is provided on an "AS IS" basis, and Hailo has no obligation to provide maintenance,
 * support, updates, enhancements, or modifications.
 *
 * You may use this software in the development of any project.
 * You shall not reproduce, modify or distribute this software without prior written permission.
 **/
/**
 * @file detection_app_c_api.cpp
 * @brief This example demonstrates running inference with virtual streams using the Hailort's C API on yolov5m
 **/
#include <ros/ros.h>

#include "std_msgs/String.h"
#include "std_msgs/Int16.h"
#include "std_msgs/Float32.h"
#include "std_msgs/UInt8MultiArray.h"
#include "std_msgs/Float32MultiArray.h"

#include "std_msgs/MultiArrayLayout.h"
#include "std_msgs/MultiArrayDimension.h"
#include "std_msgs/Int32MultiArray.h"


#include "image_transport/image_transport.h"
#include "cv_bridge/cv_bridge.h"
#include "cv_bridge/cv_bridge.h"

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <iostream>
#include <thread>
#include <vector>
#include <regex>
#include <chrono>
#include <future>
#include <fstream>
#include <memory>
#include <opencv2/opencv.hpp>
// #include <opencv2/highgui/highgui.hpp>
// #include <opencv2/videoio.hpp>


#include "common.h"
#include "hailo/hailort.h"
#include <pthread.h>
#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <boost/bind.hpp>

#define IMAGE_SIZE 640
using namespace std;
using namespace cv;

#define MAX_HEF_PATH_LEN (255)
#define MAX_NUM_OF_DEVICES (5)
#define SCAN_TIMEOUT_MILLISECONDS (2000)
#define INFER_FRAME_COUNT 1400
#define MAX_EDGE_LAYERS (16)
#define USAGE_ERROR_MSG ("Args parsing error.\nUsage: vstream_example <interface_name> </dev/video_Num>\n")
#define MAX_BATCH (64)
#define HEF_COUNT (1)
#define SHOW_DISPLAY
#define CAMERA_RT_SOURCE
#define MAXBUFF 1000

Mat mat_image_org_color;  // Image      ϱ           

cv::Mat g_frame[MAXBUFF];
uint8_t *dst_data[HEF_COUNT][MAX_EDGE_LAYERS][MAX_BATCH] = {NULL};
uint32_t g_TotalFrame = 0xFFFFFFFF;
uint32_t img_counter=0;
hailo_device device = NULL;
statistics stats;
uint8_t endflag=0;
int CamNum;

std::string get_traffic_signal_name_from_int(int cls)
{
    std::string result = "N/A";
    switch(cls) {
		case 0: result = "__background__";break;
		case 1: result = "traffic_sign_red";break;
		case 2: result = "traffic_sign_yellow";break;
		case 3: result = "traffic_sign_green";break;
		case 4: result = "traffic_sign_left_arrow";break;
		case 5: result = "traffic_sign_right_arrow";break;
		case 6: result = "traffic_sign_straight_left_arrow";break;
    }
	return result;
}

std::string get_coco_name_from_int(int cls)
{
    std::string result = "N/A";
    switch(cls) {
		case 0: result = "__background__";break;
		case 1: result = "person";break;
		case 2: result = "bicycle";break;
		case 3: result = "car";break;
		case 4: result = "motorcycle";break;
		case 5: result = "airplane";break;
		case 6: result = "bus";break;
		case 7: result = "train";break;
		case 8: result = "truck";break;
		case 9: result = "boat";break;
		case 10: result = "traffic light";break;
		case 11: result = "fire hydrant";break;
		case 12: result = "stop sign";break;
		case 13: result = "parking meter";break;
		case 14: result = "bench";break;
		case 15: result = "bird";break;
		case 16: result = "cat";break;
		case 17: result = "dog";break;
		case 18: result = "horse";break;
		case 19: result = "sheep";break;
		case 20: result = "cow";break;
		case 21: result = "elephant";break;
		case 22: result = "bear";break;
		case 23: result = "zebra";break;
		case 24: result = "giraffe";break;
		case 25: result = "backpack";break;
		case 26: result = "umbrella";break;
		case 27: result = "handbag";break;
		case 28: result = "tie";break;
		case 29: result = "suitcase";break;
		case 30: result = "frisbee";break;
		case 31: result = "skis";break;
		case 32: result = "snowboard";break;
		case 33: result = "sports ball";break;
		case 34: result = "kite";break;
		case 35: result = "baseball bat";break;
		case 36: result = "baseball glove";break;;
		case 37: result = "skateboard";break;
		case 38: result = "surfboard";break;
		case 39: result = "tennis racket";break;
		case 40: result = "bottle";break;
		case 41: result = "wine glass";break;
		case 42: result = "cup";break;
		case 43: result = "fork";break;
		case 44: result = "knife";break;
		case 45: result = "spoon";break;
		case 46: result = "bowl";break;
		case 47: result = "banana";break;
		case 48: result = "apple";break;
		case 49: result = "sandwich";break;
		case 50: result = "orange";break;
		case 51: result = "broccoli";break;
		case 52: result = "carrot";break;
		case 53: result = "hot dog";break;
		case 54: result = "pizza";break;
		case 55: result = "donut";break;
		case 56: result = "cake";break;
		case 57: result = "chair";break;
		case 58: result = "couch";break;
		case 59: result = "potted plant";break;
		case 60: result = "bed";break;
		case 61: result = "dining table";break;
		case 62: result = "toilet";break;
		case 63: result = "tv";break;
		case 64: result = "laptop";break;
		case 65: result = "mouse";break;
		case 66: result = "remote";break;
		case 67: result = "keyboard";break;
		case 68: result = "cell phone";break;
		case 69: result = "microwave";break;
		case 70: result = "oven";break;
		case 71: result = "toaster";break;
		case 72: result = "sink";break;
		case 73: result = "refrigerator";break;
		case 74: result = "book";break;
		case 75: result = "clock";break;
		case 76: result = "vase";break;
		case 77: result = "scissors";break;
		case 78: result = "teddy bear";break;
		case 79: result = "hair drier";break;
		case 80: result = "toothbrush";break;
    }
	return result;
}

void OnSignal(int sig)
{
    signal(sig, SIG_IGN);
    endflag = 1;
    ros::shutdown();
}

void free_statistics_struct(statistics* stats){
    FREE(stats->input_vstream_infos);
    FREE(stats->output_vstream_infos);
}

void print_inference_statistics(statistics* stats) {
    double start_time_secs = (double)stats->start_time.tv_sec + ((double)stats->start_time.tv_nsec / NSEC_IN_SEC);
    double end_time_secs = (double)stats->end_time.tv_sec + ((double)stats->end_time.tv_nsec / NSEC_IN_SEC);
    double infer_time_secs = end_time_secs - start_time_secs;

    printf(BOLDGREEN);
    printf("-I-----------------------------------------------\n");
    printf("-I- Total time:      %4.2lf sec\n", infer_time_secs);
    printf("-I- Average FPS:     %4.2lf\n", img_counter / infer_time_secs);
    printf(RESET);
}





/**********************************************************************************/
/* BUILD_STREAMS function                                                         */
/* input: args -                                                                  */
/*        * - network group - all hefs defined in a group                         */
/*        * - input vstreams and frame sizes                                      */
/*        * - output vstreams and frame sizes                                     */
/*        * - destination data                                                    */
/*        * - frame count                                                         */
/*                                                                                */
/* output: status                                                                 */
/*        * - Success or error code                                               */
/*                                                                                */
/* the function initializes the values for the read arguments and creates the     */
/* output thread which reads(receives the processed data) from the Hailo device   */
/**********************************************************************************/
hailo_status build_streams(hailo_configured_network_group network_group,
    hailo_input_vstream *input_vstreams, size_t *input_frame_sizes,
    hailo_output_vstream *output_vstreams, size_t *output_frame_sizes, uint8_t *(*dst_data)[MAX_BATCH],
    size_t *num_output_streams)
{
    hailo_status status = HAILO_UNINITIALIZED;
    hailo_input_vstream_params_by_name_t input_vstream_params[MAX_EDGE_LAYERS];
    hailo_output_vstream_params_by_name_t output_vstream_params[MAX_EDGE_LAYERS];

    size_t input_vstream_size = 1;
    // Make sure it can hold amount of vstreams for hailo_make_input/output_vstream_params
    size_t output_vstream_size = MAX_EDGE_LAYERS;

    // prepare all input vstreams param data in advance
    status = hailo_make_input_vstream_params(network_group, false, HAILO_FORMAT_TYPE_AUTO,
        input_vstream_params, &input_vstream_size);
    REQUIRE_SUCCESS(status, l_exit, "Failed making input virtual stream params");

    // prepare all output vstreams param data in advance
    status = hailo_make_output_vstream_params(network_group, false, HAILO_FORMAT_TYPE_FLOAT32,
        output_vstream_params, &output_vstream_size);
    REQUIRE_SUCCESS(status, l_exit, "Failed making output virtual stream params");
    *num_output_streams = output_vstream_size;

    // create all input vstreams data in advance
    status = hailo_create_input_vstreams(network_group, input_vstream_params, input_vstream_size, input_vstreams);
    REQUIRE_SUCCESS(status, l_exit, "Failed creating virtual stream");

    // create all output vstreams data in advance
    status = hailo_create_output_vstreams(network_group, output_vstream_params, output_vstream_size, output_vstreams);
    REQUIRE_SUCCESS(status, l_release_input_vstream, "Failed creating virtual stream");

    for (size_t i = 0; i < input_vstream_size; i++)
    {
        status = hailo_get_input_vstream_frame_size(input_vstreams[i], &input_frame_sizes[i]);
        REQUIRE_SUCCESS(status, l_clear_buffers, "Failed getting input virtual stream frame size");
    }

    for (size_t i = 0; i < output_vstream_size; i++)
    {
        status = hailo_get_output_vstream_frame_size(output_vstreams[i], &output_frame_sizes[i]);
        REQUIRE_SUCCESS(status, l_clear_buffers, "Failed getting input virtual stream frame size");

        printf("size %ld\n",output_frame_sizes[i]);

        for (uint8_t j = 0; j < MAX_BATCH; j++)
        {
            dst_data[i][j] = (uint8_t*)malloc(output_frame_sizes[i]);
            REQUIRE_ACTION(NULL != dst_data[i], status = HAILO_OUT_OF_HOST_MEMORY, l_clear_buffers, "Out of memory");
        }
    }

    status = HAILO_SUCCESS;
    goto l_exit;

l_clear_buffers:
    for (size_t i = 0; i < output_vstream_size; i++)
    {
        for (uint8_t j = 0; j < MAX_BATCH; j++)
        {
            FREE(dst_data[i][j]);
        }
    }
    (void)hailo_release_output_vstreams(output_vstreams, output_vstream_size);
l_release_input_vstream:
    (void)hailo_release_input_vstreams(input_vstreams, input_vstream_size);
l_exit:
    return status;
}

/**********************************************************************************/
/* RUN_NETWORK function                                                           */
/* input: args -                                                                  */
/*        * - network group - specific model to run                               */
/*        * - input vstreams and frame sizes                                      */
/*        * - output vstreams and frame sizes                                     */
/*        * - destination data                                                    */
/*        * - frame count                                                         */
/*                                                                                */
/* output: status                                                                 */
/*        * - Success or error code                                               */
/*                                                                                */
/* the function loads a specific model into the Hailo8 device and runs inference  */
/* it uses all the pre-prepared data in order to switch between models very fast  */
/**********************************************************************************/
#include "double_buffer.hpp"

class FeatureData {
public:
    FeatureData(uint32_t buffers_size, float32_t qp_zp, float32_t qp_scale, uint32_t width) :
    m_buffers(buffers_size), m_qp_zp(qp_zp), m_qp_scale(qp_scale), m_width(width)
    {}
    static bool sort_tensors_by_size (std::shared_ptr<FeatureData> i, std::shared_ptr<FeatureData> j) { return i->m_width < j->m_width; };

    DoubleBuffer m_buffers;
    float32_t m_qp_zp;
    float32_t m_qp_scale;
    uint32_t m_width;
};

hailo_status create_feature(hailo_output_vstream vstream, std::shared_ptr<FeatureData> &feature)
{
    hailo_vstream_info_t vstream_info = {};
    auto status = hailo_get_output_vstream_info(vstream, &vstream_info);
    if (HAILO_SUCCESS != status) {
        std::cerr << "Failed to get output vstream info with status = " << status << std::endl;
        return status;
    }

    size_t output_frame_size = 0;
    status = hailo_get_output_vstream_frame_size(vstream, &output_frame_size);
    if (HAILO_SUCCESS != status) {
        std::cerr << "Failed getting output virtual stream frame size with status = " << status << std::endl;
        return status;
    }

    feature = std::make_shared<FeatureData>(static_cast<uint32_t>(output_frame_size), vstream_info.quant_info.qp_zp,
        vstream_info.quant_info.qp_scale, vstream_info.shape.width);

    return HAILO_SUCCESS;
}



cv::Mat cv_image;

int img_width;
int img_height;
int frame_idx = 0;
void CamImageCallback(const sensor_msgs::Image::ConstPtr& msg , hailo_input_vstream vstream)
{
    hailo_status status = HAILO_UNINITIALIZED;
    size_t input_frame_size = 0;
    status = hailo_get_input_vstream_frame_size(vstream, &input_frame_size);
    cv_image = cv_bridge::toCvShare(msg,"bgr8")->image;

    img_width = cv_image.size().width;
    img_height = cv_image.size().height;
	
	printf("%3d %3d\n", img_width, img_height); 

    frame_idx = frame_idx % MAXBUFF;

    if (!cv_image.empty())
    {
        cv::resize(cv_image, g_frame[frame_idx], cv::Size(IMAGE_SIZE, IMAGE_SIZE), 1);
        status = hailo_vstream_write_raw_buffer(vstream, g_frame[frame_idx].data, input_frame_size);
        frame_idx++;
    }
}

hailo_status write_all(hailo_input_vstream input_vstream)
{
    ros::NodeHandle nh;
    //image_transport::ImageTransport it(nh);

    (void) clock_gettime(CLOCK_MONOTONIC, &(stats.start_time));

    ros::Subscriber cam_image_sub = nh.subscribe<sensor_msgs::Image>("usb_cam/image_raw", 1, boost::bind(&CamImageCallback,_1,input_vstream));

    ros::Rate loop_rate(30.0); //10.0HZ
    ros::spin();

    return HAILO_SUCCESS;
}




#define YMIN                 0
#define XMIN                 1
#define YMAX                 2
#define XMAX                 3


inline float minm(float n1, float n2)
{
     if (n1<n2) {
         return n1;
     }
     return n2;
}

inline float maxm(float n1, float n2)
{
     if (n1>n2) {
         return n1;
     }
     return n2;
}

float32_t iou_calc_c(float32_t *box_1, float32_t *box_2)
{
    float width_of_overlap_area  = minm(box_1[XMAX], box_2[XMAX]) - maxm(box_1[XMIN], box_2[XMIN]);
    float height_of_overlap_area = minm(box_1[YMAX], box_2[YMAX]) - maxm(box_1[YMIN], box_2[YMIN]);
    float positive_width_of_overlap_area = maxm(width_of_overlap_area + 1, 0.0f);
    float positive_height_of_overlap_area = maxm(height_of_overlap_area + 1, 0.0f);
    float area_of_overlap = positive_width_of_overlap_area * positive_height_of_overlap_area;
    float box_1_area = (box_1[YMAX] - box_1[YMIN] + 1)  * (box_1[XMAX] - box_1[XMIN] + 1);
    float box_2_area = (box_2[YMAX] - box_2[YMIN] + 1)  * (box_2[XMAX] - box_2[XMIN] + 1);
    return area_of_overlap / (box_1_area + box_2_area - area_of_overlap);

}
#define MAX_CLASSES  6




unsigned long GetTickCount()
{
    struct timespec tp;

    clock_gettime(CLOCK_MONOTONIC,&tp);
    return (unsigned long)(tp.tv_sec *1000 + tp.tv_nsec / 1000000);
}



/**********************************************************************************/
/* READ_FROM_DEVICE function                                                      */
/* input: args -                                                                  */
/*        * - the virtual stream to receive the data                              */
/*        * - a ptr to the data to read                                           */
/*        * - the data length and the                                             */
/*                                                                                */
/* output: status                                                                 */
/*        * - Success or error code                                               */
/**********************************************************************************/

float32_t * ptr;//[200000];//=&(features[0]->m_buffers.get_read_buffer().data()[0]);
hailo_status read_all(hailo_output_vstream output_vstream, std::shared_ptr<FeatureData> feature)
{
    float32_t boxes[2000][4]={0};
    uint32_t  classes[2000]={0};
    float32_t confidence[2000]={0};

    uint32_t NumberOfDetection=0, a=0;

	printf("start read all\n");

    unsigned long gapTime;
    unsigned long curTime = GetTickCount();
    gapTime = curTime;

#if 1

	/**
	* NodeHandle is the main access point to communications with the ROS system.
	* The first NodeHandle constructed will fully initialize this node, and the last
	* NodeHandle destructed will close down the node.
	*/
	ros::NodeHandle nh;
    image_transport::ImageTransport it(nh);
    image_transport::Publisher haio_ai_img_pub  = it.advertise("ai/result_image", 1);    // image publish


    
    ros::Publisher hailo_ai_class_confidence      = nh.advertise<std_msgs::Float32MultiArray>("ai/class_confidence", 1);
    ros::Publisher hailo_ai_class_id              = nh.advertise<std_msgs::UInt8MultiArray>("ai/class_id", 1);
    ros::Publisher hailo_ai_class_box             = nh.advertise<std_msgs::Float32MultiArray>("ai/class_box", 1);
    
    
    /*
    ros::Publisher hailo_ai_class_no              = nh.advertise<std_msgs::Int16>("ai/class_no", 1);                        // detectd class number publish    
    ros::Publisher hailo_ai_max_class_id          = nh.advertise<std_msgs::Int16>("ai/max_class_id", 1);                    // detectd class number publish
    ros::Publisher hailo_ai_max_class_confidence  = nh.advertise<std_msgs::Float32>("ai/max_class_confidence", 1);          // detectd class number publish
    */
    

    sensor_msgs::ImagePtr img_msg = cv_bridge::CvImage(std_msgs::Header(), "bgr8", mat_image_org_color).toImageMsg();
	ros::Rate loop_rate(30.0); //10.0HZ

#endif

    for (size_t pic = 0; ; pic++)
    {
        if (!ros::ok())
        {
            break;
        }

        printf("\n\n\n\n");
		printf("ros ok\n");

        pic = pic%MAXBUFF;
		printf("pic: %ld\n", pic);

        auto &buffer = feature->m_buffers.get_write_buffer();
		printf("Got write buffer\n");

        hailo_status status = hailo_vstream_read_raw_buffer(output_vstream, buffer.data(), buffer.size());
		printf("read raw buffer\n");

        feature->m_buffers.release_write_buffer();
		printf("release write_buffer\n");

        uint32_t idx=0, offset=0;

        ptr = buffer.data();

		if (ptr == NULL)
		{
			printf("ptr is NULL");
			continue;
		}

        NumberOfDetection=0;
        a=0;

        for (uint32_t r = 0; r < MAX_CLASSES+offset; r++)
        {
            if ((ptr[r]) >=1.0)
            {
                for (uint32_t t = r+1; t < r+ptr[r]*5; t=t+5)
                {
                    boxes[NumberOfDetection][0] = (IMAGE_SIZE*ptr[t+0]);
                    boxes[NumberOfDetection][1] = (IMAGE_SIZE*ptr[t+1]);
                    boxes[NumberOfDetection][2] = (IMAGE_SIZE*ptr[t+2]);
                    boxes[NumberOfDetection][3] = (IMAGE_SIZE*ptr[t+3]);
                    classes[NumberOfDetection]  = idx+1;
                    confidence[NumberOfDetection] = ptr[t+4];
                    printf("detected class id    : %2d\n",  classes[NumberOfDetection]);
                    printf("detected class conf. : %.2f\n", confidence[NumberOfDetection]);

                    NumberOfDetection++;
                    offset += 5;
                    a+=5;
                }
                r += a;
            }
            idx++;
        }


		printf("Number of Detection %d\n",NumberOfDetection);
		
		std_msgs::Float32MultiArray class_confidence_array_msg;
		std_msgs::UInt8MultiArray   class_id_array_msg;
		std_msgs::Float32MultiArray class_box_array_msg;
		
		
		if(NumberOfDetection > 0)
		{
			
			int rows = NumberOfDetection; 
			int cols = 4;
			
			class_box_array_msg.layout.dim.push_back(std_msgs::MultiArrayDimension());
			class_box_array_msg.layout.dim.push_back(std_msgs::MultiArrayDimension());
			class_box_array_msg.layout.dim[0].size = rows;
			class_box_array_msg.layout.dim[1].size = cols;
			class_box_array_msg.layout.dim[0].stride = cols;
			class_box_array_msg.layout.dim[1].stride = 1;
			class_box_array_msg.layout.data_offset = 0;
		
			// NMS
            for (uint32_t i = 0; i < NumberOfDetection; ++i)
            {
				
				for (int j = 0; j < cols; ++j)
				{
					class_box_array_msg.data.push_back(1.0 + i * cols + j);
				}        
				class_confidence_array_msg.data.push_back(confidence[i]);
				class_id_array_msg.data.push_back(classes[i]);
			}
			
		}
        

/*
        std_msgs::Int16 no_class_msg, max_class_id_msg;
        std_msgs::Float32 max_class_id_confidence_msg;

        max_class_id_msg.data = -1;
        max_class_id_confidence_msg.data = 0.0;

       
        if(NumberOfDetection > 0)
        {
            // NMS
            for (uint32_t i = 0; i < NumberOfDetection; ++i)
            {
				
				if( confidence[i] >= max_class_id_confidence_msg.data )
				{
					max_class_id_confidence_msg.data = confidence[i];
					max_class_id_msg.data            = classes[i];
					printf("max_class_id_msg.data  : %d\n", max_class_id_msg.data);
				}
			}
			
			
		}
*/
        
        for (uint32_t q = 0; q < NumberOfDetection; q++)
        {
            if (classes[q] == 0)
                continue;
            if (boxes[q][0]>0 && boxes[q][1]>0)
                cv::rectangle(g_frame[pic], cv::Point2f(uint32_t(boxes[q][1]), uint32_t(boxes[q][0])),
                                        cv::Point2f(uint32_t(boxes[q][3]), uint32_t(boxes[q][2])),
                                        cv::Scalar(0, 0, 255), 3);
        }
#if 1
        // Publish msg
		sensor_msgs::ImagePtr msg = cv_bridge::CvImage(std_msgs::Header(), "bgr8", g_frame[pic]).toImageMsg();
		haio_ai_img_pub.publish(msg);
		
		hailo_ai_class_confidence.publish(class_confidence_array_msg);
		hailo_ai_class_id.publish(class_id_array_msg); 
		hailo_ai_class_box.publish(class_box_array_msg);
		
        /*
        

        no_class_msg.data = NumberOfDetection;
        hailo_ai_class_no.publish(no_class_msg);

        hailo_ai_max_class_id.publish(max_class_id_msg);
        hailo_ai_max_class_confidence.publish(max_class_id_confidence_msg);
        */ 

	printf("published ros command\n");
#endif
        g_frame[pic].release();

        feature->m_buffers.release_read_buffer();
		img_counter++;

#if 1
        curTime = GetTickCount();


        if( curTime-gapTime>60)
        {
            printf("[Time = %ld]\n", curTime- gapTime);
            gapTime = curTime;
            ros::spinOnce();
        }
#endif
    }


    (void) clock_gettime(CLOCK_MONOTONIC, &(stats.end_time));

    return HAILO_SUCCESS;
}


hailo_status post_processing_all(std::vector<std::shared_ptr<FeatureData>> &features)
{
    std::sort(features.begin(), features.end(), &FeatureData::sort_tensors_by_size);
    return HAILO_SUCCESS;
}



hailo_status run_network(hailo_configured_network_group network_group, hailo_input_vstream input_vstream, uint16_t frames_count, size_t input_frame_size, hailo_output_vstream *output_vstreams, size_t output_vstreams_size, uint8_t *(*dst_data)[MAX_BATCH], size_t *output_frame_size)
{
    hailo_status status = HAILO_SUCCESS; // Success oriented
    hailo_activated_network_group activated_network_group = NULL;

    printf("-I- Running network. Input frame size: %lu\n", input_frame_size);

    // Activating the specific model we would like to run within the network group
    status = hailo_activate_network_group(network_group, NULL, &activated_network_group);
    //REQUIRE_SUCCESS(status, l_exit, "Failed activate network group");

   // Create features data to be used for post-processing
    std::vector<std::shared_ptr<FeatureData>> features;
    features.reserve(output_vstreams_size);
    for (size_t i = 0; i < output_vstreams_size; i++) {
        std::shared_ptr<FeatureData> feature(nullptr);
        auto status = create_feature(output_vstreams[i], feature);
        if (HAILO_SUCCESS != status) {
            std::cerr << "Failed creating feature with status = " << status << std::endl;
            return status;
        }

        features.emplace_back(feature);
    }

    // Create write thread
    auto input_thread(std::async(write_all, input_vstream));




    // Create read threads
    std::vector<std::future<hailo_status>> output_threads;
    output_threads.reserve(output_vstreams_size);
    for (size_t i = 0; i < output_vstreams_size; i++) {
        output_threads.emplace_back(std::async(read_all, output_vstreams[i], features[i]));
    }


    // End threads
    for (size_t i = 0; i < output_threads.size(); i++) {
         status = output_threads[i].get();
    }
    auto input_status = input_thread.get();

    if (HAILO_SUCCESS != input_status) {
        std::cerr << "Write thread failed with status " << input_status << std::endl;
        return input_status;
    }
    if (HAILO_SUCCESS != status) {
        std::cerr << "Read failed with status " << status << std::endl;
        return status;
    }


    std::cout << "Inference finished successfully" << std::endl;

    status = hailo_deactivate_network_group(activated_network_group);
    //REQUIRE_SUCCESS(status, l_exit, "Failed activate network group");

//l_exit:
    return status;
}

void parse_arguments(int argc, char **argv, const char **interface_name)
{
    if (3 != argc) {
        printf(USAGE_ERROR_MSG);
        exit(1);
    }
    *interface_name = argv[1];
    CamNum = atoi(argv[2]);
}

int main(int argc, char **argv)
{
    hailo_status status = HAILO_UNINITIALIZED;

    char *interface_name;

    hailo_eth_device_info_t device_infos[MAX_NUM_OF_DEVICES] = {0};
    size_t num_of_devices = 0;
    uint32_t timeout = SCAN_TIMEOUT_MILLISECONDS;
    hailo_hef hef = NULL;
    hailo_configure_params_t config_params = {0};
    hailo_configured_network_group network_groups[HEF_COUNT] = {NULL};
    size_t network_group_size = 1;
    hailo_input_vstream input_vstreams[HEF_COUNT][MAX_EDGE_LAYERS];
    hailo_output_vstream output_vstreams[HEF_COUNT][MAX_EDGE_LAYERS];
    size_t input_frame_size[HEF_COUNT][MAX_EDGE_LAYERS];
    size_t output_frame_size[HEF_COUNT][MAX_EDGE_LAYERS];

    size_t num_output_vstreams[HEF_COUNT] = {0};
	uint8_t hef_index = 0;
    char *HEF_FILE_ETH;

    ros::init(argc, argv, "ros_hailo_ai");
   
    ros::NodeHandle nh;

    std::string _interfacename;
    std::string _heffile; 
    std::string interface = "enxb686b51e0e23";                                                     // interface 이름 바꿀 것   
    std::string path = "/home/amap/Work/Hailo/hef_files/cone.hef";   //  weight 이름 바꿀 것
   
   
   // ros::param::get("~use_utm_absolute_mode", use_utm_absolute_mode);
    nh.param("/InterfaceName",_interfacename,interface);
    nh.param("/HEF_File",_heffile,path);


    //if(!nh.getParam("InterfaceName",_interfacename)) printf("InterfaceName param Fail");
    //ros::param::param<std::string>("InterfaceName", _interfacename, "default_value");
    //if(!nh.getParam("HEF_File",_heffile)) printf("HEF_File param Fail");

    //printf("----------%s-------------\n",_interfacename.c_str());
    //printf("----------%s-------------\n",_heffile.c_str());

    interface_name = const_cast<char*>(_interfacename.c_str());
    HEF_FILE_ETH = const_cast<char*>(_heffile.c_str());

    signal(SIGINT,OnSignal);
    sleep(1);
  
    printf("interface_name %s\n",interface_name);

    status = hailo_scan_ethernet_devices(interface_name, device_infos, MAX_NUM_OF_DEVICES, &num_of_devices, timeout);
    //REQUIRE_SUCCESS(status, l_exit, "Failed to scan ethernet devices");
    //REQUIRE_ACTION(num_of_devices > 0, status = HAILO_INVALID_ARGUMENT, l_exit,
    //	"Failed to find ethernet devices");

    status = hailo_create_ethernet_device(&device_infos[0], &device);
    //REQUIRE_SUCCESS(status, l_exit, "Failed to create eth_device");
    status = hailo_create_hef_file(&hef, HEF_FILE_ETH);
    ///REQUIRE_SUCCESS(status, l_release_vstreams, "Failed creating hef file %s", HEF_FILE_ETH);


    /*******************************/
    /* MODEL PREPARATION PART      */
    /*******************************/
    //config_params.network_group_params[0].stream_params_by_name[0].stream_params.eth_input_params.rate_limit_bytes_per_sec   = 10000000;

    status = hailo_init_configure_params(hef, HAILO_STREAM_INTERFACE_ETH, &config_params);
    //status = hailo_init_configure_params(hef, HAILO_STREAM_INTERFACE_PCIE, &config_params);

    REQUIRE_SUCCESS(status, l_release_device, "Failed init configure params");
    config_params.network_group_params[0].stream_params_by_name[0].stream_params.eth_input_params.rate_limit_bytes_per_sec   = 800000000;

        status = hailo_configure_device(device, hef, &config_params, &network_groups[hef_index], &network_group_size);
    REQUIRE_SUCCESS(status, l_release_hef, "Failed configure devcie from hef");
    REQUIRE_ACTION(network_group_size == 1, status = HAILO_INVALID_ARGUMENT, l_release_hef,
        "Invalid network group size");
    //config_params.network_group_params[0].stream_params_by_name[0].stream_params.eth_input_params.rate_limit_bytes_per_sec   = 10000000;

    status = build_streams(network_groups[hef_index],
        input_vstreams[hef_index], input_frame_size[hef_index],
        output_vstreams[hef_index], output_frame_size[hef_index],
        dst_data[hef_index], &num_output_vstreams[hef_index]);
    REQUIRE_SUCCESS(status, l_release_hef, "Failed building streams");


    /*******************************/
    /* INFERENCE PART              */
    /*******************************/

    status = run_network(network_groups[0], input_vstreams[0][0], 1, input_frame_size[0][0], output_vstreams[0], num_output_vstreams[0], dst_data[0], output_frame_size[0]);
    REQUIRE_SUCCESS(status, l_release_vstreams, "Failed to run YoloV5m");
    printf("-I- YoloV5 ran successfully.\n");

    printf("Inference ran successfully\n");

    print_inference_statistics(&stats);

    status = HAILO_SUCCESS;
	l_release_vstreams:
	l_release_hef:
    (void) hailo_release_hef(hef);
	l_release_device:
    (void) hailo_release_device(device);
    return status;
}



