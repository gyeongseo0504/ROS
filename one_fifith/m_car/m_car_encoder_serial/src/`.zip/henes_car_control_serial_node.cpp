#define DEBUG 0
#define DEBUG_ROS_INFO 1 

#include "ros/ros.h"
#include "std_msgs/String.h"
#include "std_msgs/Int16.h"
#include "std_msgs/Int32.h"
#include "std_msgs/Float32.h"
#include "geometry_msgs/Twist.h"
#include "sensor_msgs/LaserScan.h"
#include "sensor_msgs/Range.h"
#include "sensor_msgs/Imu.h"
#include "tf/transform_broadcaster.h"
#include "nav_msgs/Odometry.h"
#include "tf2_geometry_msgs/tf2_geometry_msgs.h"
#include "geometry_msgs/Vector3.h"
#include <pthread.h>
#include <sstream>
#include <iostream>

#include <geometry_msgs/Vector3.h>
#include <stdio.h>
#include <stdlib.h>

#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/poll.h>
#include <termios.h>                   // B115200, CS8 등 상수 정의
#include <fcntl.h>                     // O_RDWR , O_NOCTTY 등의 상수 정의
#include <time.h>
#include <math.h>

using namespace std;

#define RAD2DEG(x) ((x)*180./M_PI)
#define DEG2RAD(x) ((x)/180.*M_PI)
#define LOOP_RATE            50
// unit m
#define Sonar_Detect_MAX_Range 3.0
#define Sonar_Obstacle_Range   1.0
#define Lidar_Obstacle_Range   1.0

// Steering Control
#define Neutral_Angle_Offset  3
#define Right_MAX -25
#define Left_MAX  25
#define STEER_NEUTRAL_ANGLE 3

union
{
    float data ;
    char  bytedata[4];
    
} m_current_robot_speed_float;

union
{
    short data ;
    char  bytedata[2];
    
} m_robot_angle_int16;

union
{
    int data ;
    char  bytedata[4];
    
} m_car_encoder_int;


static int uart_fd;

int steering_angle = 0;
int steering_angle_cmd = 0;
float motor_speed = 0.0;
float motor_speed_cmd = 0.0;

int Base_Speed = 60;
int steering_angle_old = 0;
float motor_speed_old = 0;
float sonar[3]={0.0,};
long encoder1data = 0;
long encoder2data = 0;

double roll,pitch,yaw,yaw_old;
double roll_d,pitch_d,yaw_d,yaw_d_old;
double delta_yaw_d, delta_yaw;
int  imu_read_flag_start = 0;
bool imu_init_angle_flag = 0;
double init_yaw_angle = 0.0;
double init_yaw_angle_d = 0.0;

double imu_heading_anlge_offset = 0.0 ; //degree

double m_acceleration =  0.05;   //henes speed acceleratoin
double m_deceleration =  0.05;  //henes speed

double s_acceleration =  1;   //henes steer
double s_deceleration =  1;   //henes steer

double odom_init_x = 0.0;
double odom_init_y = 0.0;

struct BaseSensorData
{
    int encoder = 0;   
    int encoder_old = 0; 
}myBaseSensorData;

union
{
    float data ;
    char  bytedata[4];
} m_robot_speed;

void write_serial(unsigned char *buf, int len)
{
        for(int i=0; i<len+1; i++){
	  write(uart_fd, &buf[i], 1);
        }
} 

#define BAUDRATE          B38400
#define SERIAL_DEVICE   "/dev/ttyUSB0"


unsigned char protocal_test[12] ={0,};
unsigned char read_buf [20];
unsigned char readbuf[20];

int init_serial_port(void)
{
  int serial_port = open(SERIAL_DEVICE, O_RDWR);

  // Create new termios struct, we call it 'tty' for convention
  struct termios tty;

  // Read in existing settings, and handle any error
  if(tcgetattr(serial_port, &tty) != 0) {
      printf("Error %i from tcgetattr: %s\n", errno, strerror(errno));
      return 1;
  }

  tty.c_cflag &= ~PARENB; // Clear parity bit, disabling parity (most common)
  tty.c_cflag &= ~CSTOPB; // Clear stop field, only one stop bit used in communication (most common)
  tty.c_cflag &= ~CSIZE; // Clear all bits that set the data size 
  tty.c_cflag |= CS8; // 8 bits per byte (most common)
  tty.c_cflag &= ~CRTSCTS; // Disable RTS/CTS hardware flow control (most common)
  tty.c_cflag |= CREAD | CLOCAL; // Turn on READ & ignore ctrl lines (CLOCAL = 1)

  tty.c_lflag &= ~ICANON;
  tty.c_lflag &= ~ECHO; // Disable echo
  tty.c_lflag &= ~ECHOE; // Disable erasure
  tty.c_lflag &= ~ECHONL; // Disable new-line echo
  tty.c_lflag &= ~ISIG; // Disable interpretation of INTR, QUIT and SUSP
  tty.c_iflag &= ~(IXON | IXOFF | IXANY); // Turn off s/w flow ctrl
  tty.c_iflag &= ~(IGNBRK|BRKINT|PARMRK|ISTRIP|INLCR|IGNCR|ICRNL); // Disable any special handling of received bytes

  tty.c_oflag &= ~OPOST; // Prevent special interpretation of output bytes (e.g. newline chars)
  tty.c_oflag &= ~ONLCR; // Prevent conversion of newline to carriage return/line feed
  // tty.c_oflag &= ~OXTABS; // Prevent conversion of tabs to spaces (NOT PRESENT ON LINUX)
  // tty.c_oflag &= ~ONOEOT; // Prevent removal of C-d chars (0x004) in output (NOT PRESENT ON LINUX)

  tty.c_cc[VTIME] = 100;    // Wait for up to 1s (10 deciseconds), returning as soon as any data is received.
  tty.c_cc[VMIN] = 0;

  // Set in/out baud rate to be 38400
  cfsetispeed(&tty, BAUDRATE);
  cfsetospeed(&tty, BAUDRATE);

  // Save tty settings, also checking for error
  if (tcsetattr(serial_port, TCSANOW, &tty) != 0) {
      printf("Error %i from tcsetattr: %s\n", errno, strerror(errno));
      return -1;
  }
    
  else
  {
      return serial_port;
  } 
}




void *readserial_thread(void *pt)
{
	//pthread_t tid;    
    //tid=pthread_self(); 
	
	int num_bytes  = -1;
	unsigned char insert_buf;
	
	while(1)
	    {
		//printf("thread starts\n");
		//num_bytes = read(uart_fd, &insert_buf, 1);
			while((num_bytes = read(uart_fd, &insert_buf, 1)) > 0 )	
			{
				//printf("thread starts\n");
			for(int i=0; i<7; i++)
			    {
					readbuf[i]=readbuf[i+1];
					//printf(" %c ",readbuf[i]);
				}
		
			readbuf[6] = insert_buf;
			//printf("%c \n",readbuf[6]);	
			if((readbuf[0] == '#') && (readbuf[1] == 'E') && (readbuf[6] == '*'))
			    {
				 for(int i=0; i<4; i++)
					{
					 m_car_encoder_int.bytedata[i]=readbuf[i+2];
					 //printf(" %d ",readbuf[i]);
					}
				 printf("encoder count : %d",m_car_encoder_int.data);
				}
			}
		}
}



void send_serial_data(void)
{
    unsigned short protocal_crc16;
    
    protocal_test[0] = '#';
    protocal_test[1] = 'C';
    
    protocal_test[2] = m_robot_angle_int16.bytedata[0];
    protocal_test[3] = m_robot_angle_int16.bytedata[1];
    
    protocal_test[4] = m_current_robot_speed_float.bytedata[0];
    protocal_test[5] = m_current_robot_speed_float.bytedata[1];  
    protocal_test[6] = m_current_robot_speed_float.bytedata[2];  
    protocal_test[7] = m_current_robot_speed_float.bytedata[3];    
    protocal_test[8] = '*';
    
    printf("steer %3d \n", m_robot_angle_int16.data);
    printf("speed %6.3f \n", m_current_robot_speed_float.data);
    
    //printf("protocal CRC16 %X \n", protocal_crc16);
    write_serial(protocal_test,8);
}


struct OdomCaculateData
{
    //motor params
    float distance_ratio= 348.0 ;//0.000176; //unit: m/encode  338.0  //henes car 확인 할 것
    float encode_sampling_time=0.05; //unit: s-> 20hz
    float cmd_vel_linear_max= 1.2; //unit: m/s
    float cmd_vel_angular_max=0.8; //unit: rad/s
    //odom result
    float position_x=0.0; //unit: m
    float position_y=0.0; //unit: m
    float oriention=0.0; //unit: rad
    float velocity_linear=0.0; //unit: m/s
    float velocity_angular=0.0; //unit: rad/s
    
}myOdomCaculateData;

void imuCallback(const sensor_msgs::Imu::ConstPtr& msg) 
{
	
	 char buf[8];
  /*
   *   ROS_INFO( "Accel: %.3f,%.3f,%.3f [m/s^2] - Ang. vel: %.3f,%.3f,%.3f [deg/sec] - Orient. Quat: %.3f,%.3f,%.3f,%.3f",
              msg->linear_acceleration.x, msg->linear_acceleration.y, msg->linear_acceleration.z,
              msg->angular_velocity.x, msg->angular_velocity.y, msg->angular_velocity.z,
              msg->orientation.x, msg->orientation.y, msg->orientation.z, msg->orientation.w);
    */        
      tf2::Quaternion q(
        msg->orientation.x,
        msg->orientation.y,
        msg->orientation.z,
        msg->orientation.w);
      tf2::Matrix3x3 m(q);     
            
      m.getRPY(roll, pitch, yaw);
      roll_d  = RAD2DEG(roll);
      pitch_d = RAD2DEG(pitch);
      yaw_d   = RAD2DEG(yaw); 
      //printf("yaw_d: %lf \n", yaw_d);       
            
}

void imu_yaw_offset_Callback(const std_msgs::Float32& msg)
{
	imu_heading_anlge_offset = msg.data;
}

void CarControlCallback(const geometry_msgs::Twist& msg)
{
   steering_angle_cmd = (int)(msg.angular.z) ;
   
   if(steering_angle_cmd >= Left_MAX )   steering_angle_cmd = Left_MAX ;
   if(steering_angle_cmd <= Right_MAX )  steering_angle_cmd = Right_MAX ;
   
   motor_speed_cmd = (float)(msg.linear.x);

}

void CarSteerControlCallback(const std_msgs::Int16& angle)
{
  steering_angle_cmd = (int)(angle.data) ;
  
  if(steering_angle_cmd >= Left_MAX )   steering_angle_cmd = Left_MAX ;
  if(steering_angle_cmd <= Right_MAX )  steering_angle_cmd = Right_MAX ;   
  
}

void CarSpeedControlCallback(const std_msgs::Float32 speed)
{
  motor_speed_cmd = (float)speed.data;
   if(motor_speed_cmd>=3.0)   motor_speed_cmd = 3.0;
   if(motor_speed_cmd<=-3.0)  motor_speed_cmd = -3.0;   
  
}

void scanCallback(const sensor_msgs::LaserScan::ConstPtr& scan)
{
    int count = (int)( 360. / RAD2DEG(scan->angle_increment));
    int sum=0; 
    
    for(int i = 0; i < count; i++)
    {
        float degree = RAD2DEG(scan->angle_min + scan->angle_increment * i);
        
        if(((degree>=90-15)&&(degree<=90+15)))
        {
          ROS_INFO(": [%f, %f]", degree, scan->ranges[i]);
          if(scan->ranges[i] <= Lidar_Obstacle_Range) 
          {
            sum++;
          }
          
        }
      
    }
     if(sum >=10)   
     {
       motor_speed_cmd = 0;
       ROS_INFO("Lidar Obstacle Detected !!");
       sum=0;
     }
     else           motor_speed = Base_Speed;     
}

                   
void odometry_cal(void)
{		
	int delta_encoder = myBaseSensorData.encoder - myBaseSensorData.encoder_old;
	double base_link_delta_x;   double base_link_delta_y;  double base_link_delta_l;
	double odom_delta_x;        double odom_delta_y;  
	double radius;
	double temp = yaw;
//	double temp_d = yaw_d;

//	delta_yaw_d = yaw_d - yaw_d_old;

	delta_yaw = yaw - yaw_old;

	
	base_link_delta_l =  (double)delta_encoder ;  /// myOdomCaculateData.distance_

	if(fabs(delta_yaw)>1.0e-7) 
	{
	  
		radius = base_link_delta_l / delta_yaw;
		if(delta_yaw < 0)  base_link_delta_y = -radius*(1 - cos(delta_yaw));
		else               base_link_delta_y =  radius*(1 - cos(delta_yaw));

		base_link_delta_x = radius * sin(delta_yaw);	
		  
	}
	else  
	{
		base_link_delta_x = base_link_delta_l;
		base_link_delta_y = 0.0;
	}  
	
	//여기에 encoder를 distance 로 변화는 계수를 곱해야 함 거리가 나와야 함 계숙확인 바람
	
	base_link_delta_x /= myOdomCaculateData.distance_ratio;
	base_link_delta_y /= myOdomCaculateData.distance_ratio;
    
    
	odom_delta_x =  base_link_delta_x * cos(yaw_old)  - base_link_delta_y * sin(yaw_old);   // rotation_matrix
	odom_delta_y =  base_link_delta_x * sin(yaw_old)  + base_link_delta_y * cos(yaw_old);
    
    
    //odom_delta_x = base_link_delta_x;
    //odom_delta_y = base_link_delta_y;
    
	myOdomCaculateData.position_x += odom_delta_x; //unit: m
	myOdomCaculateData.position_y += odom_delta_y; //unit: m
	myOdomCaculateData.oriention   = yaw ; //unit: rad
	
	printf("obom data : %6.3lf %6.3lf %6.3lf \n",myOdomCaculateData.position_x,myOdomCaculateData.position_y,RAD2DEG(myOdomCaculateData.oriention));	

	if(DEBUG == 1)printf(" %6.3lf %6.3lf %6.3lf \n", 	myOdomCaculateData.position_x, myOdomCaculateData.position_y, RAD2DEG(myOdomCaculateData.oriention));
	 
//	yaw_d_old = temp_d;       
	yaw_old = temp;      
}



void robot_steer_profile_control(void)
{
	if(steering_angle > steering_angle_cmd)   
	{
	steering_angle -=  s_deceleration / LOOP_RATE;
	steering_angle = (steering_angle <= steering_angle_cmd ) ? steering_angle_cmd : steering_angle;
	}
	else if(steering_angle < steering_angle_cmd)
	{  
	steering_angle +=  s_acceleration / LOOP_RATE; 
	steering_angle = (steering_angle >= steering_angle_cmd) ? steering_angle_cmd : steering_angle;
	}
	else 
	{
	  steering_angle = steering_angle_cmd;
	}
}

void robot_speed_profile_control(void)
{
	if(motor_speed > motor_speed_cmd)   //현재 속도가 명령 속도 보다 클 때 , 감속 조건  m_robot_speed 가 명령어임
	{
	motor_speed -=  m_deceleration / LOOP_RATE;
	motor_speed = (motor_speed <= motor_speed_cmd ) ? motor_speed_cmd : motor_speed;
	}
	else if(motor_speed < motor_speed_cmd) //현재 속도가 명령속도 보다 클때 , 가속 조건
	{ 
	motor_speed +=  m_acceleration / LOOP_RATE; 
	motor_speed = (motor_speed >= motor_speed_cmd) ? motor_speed_cmd : motor_speed;
	}
	else 
	{
	  motor_speed = motor_speed_cmd;
	}
}
  

int main(int argc, char **argv)
{
	char buf[2];
	ros::init(argc, argv, "Henes_Car_Control_Serial");

	ros::NodeHandle n;

	std::string cmd_vel_topic              = "/cmd_vel";
	std::string odom_pub_topic             = "/odom/car";
	//std::string imu_topic                = "/handsfree/imu";
	std::string imu_topic                  = "/robor/imu/data";;
	std::string imu_yaw_offset_angle_topic = "/imu/yaw_offset_degree"; 
	std_msgs::Int16 encoder;

	uart_fd = init_serial_port();

	pthread_t id_1;
	int ret1=pthread_create(&id_1,NULL,*readserial_thread,NULL);

	/*other*/
	ros::param::get("~m_acceleration", m_acceleration); //acceleraton  parameter of of motor
	ros::param::get("~m_deceleration", m_deceleration); //deceleration parameter of motor
	ros::param::get("~s_acceleration", s_acceleration); //acceleraton  parameter of steering
	ros::param::get("~s_deceleration", s_deceleration); //deceleration parameter of steering

	ros::param::get("~cmd_vel_topic", cmd_vel_topic);
	ros::param::get("~odom_pub_topic", odom_pub_topic);
	ros::param::get("~imu_topic", imu_topic); 
	ros::param::get("~imu_yaw_offset_angle_topic",  imu_yaw_offset_angle_topic);


	std_msgs::String msg;
	std_msgs::Int16 steerangle;
	std_msgs::Int16 carspeed;


	geometry_msgs::Twist teleop_cmd_vel_data;


	cout << "m_acceleration : " << m_acceleration << endl;  
	cout << "m_deceleration : " << m_deceleration << endl;

	cout << "s_acceleration : " << s_acceleration << endl;  
	cout << "s_deceleration : " << s_deceleration << endl;

	ros::Subscriber sub1                     = n.subscribe("/cmd_vel", 1, &CarControlCallback);
	ros::Subscriber sub2                     = n.subscribe("/Car_Control_cmd/Vision_SteerAngle_Int16",1, &CarSteerControlCallback);
	//ros::Subscriber sub2                     = n.subscribe("Car_Control_cmd/SteerAngle_Int16",1, &CarSteerControlCallback);  //
	ros::Subscriber sub4                     = n.subscribe("Car_Control_cmd/Speed_Float32",1, &CarSpeedControlCallback);  

	ros::Subscriber subIMU                   = n.subscribe(imu_topic, 1, &imuCallback);  // imu data susscribe
	ros::Subscriber sub_IMU_yaw_offset_angle = n.subscribe(imu_yaw_offset_angle_topic, 1, imu_yaw_offset_Callback);
	 
	ros::Publisher odom_pub = n.advertise<nav_msgs::Odometry>(odom_pub_topic, 20);
	ros::Rate loop_rate(LOOP_RATE);  // 10

	/**
	* A count of how many messages we have sent. This is used to create
	* a unique string for each message.
	*/
	int count = 0;

	//////////////////  odometry  //////////////////////
	std::string odom_frame_id = "odom";
	std::string odom_child_frame_id = "base_link";

	////////////////  TF odometry  //////////////////////
	static tf::TransformBroadcaster odom_broadcaster;
	geometry_msgs::TransformStamped odom_trans;
	nav_msgs::Odometry odom;
	geometry_msgs::Quaternion odom_quat;

	//covariance matrix
	float covariance[36] = {0.01,   0,    0,     0,     0,     0,  // covariance on gps_x
							0,  0.01, 0,     0,     0,     0,  // covariance on gps_y
							0,  0,    99999, 0,     0,     0,  // covariance on gps_z
							0,  0,    0,     99999, 0,     0,  // large covariance on rot x
							0,  0,    0,     0,     99999, 0,  // large covariance on rot y
							0,  0,    0,     0,     0,     0.01};  // large covariance on rot z 
	//load covariance matrix
	for(int i = 0; i < 36; i++)
	{
	  odom.pose.covariance[i] = covariance[i];;
	}     

	ros::Duration(1).sleep();   // 1 sec stop for safety

	while (ros::ok())
	{
		robot_speed_profile_control();
		robot_steer_profile_control();
		ROS_INFO("Cur Speed : %3.3f | Cmd Speed : %3.3f | Steering : %2d | Cmd Steering : %2d", motor_speed, motor_speed_cmd,steering_angle,steering_angle_cmd);    
		/////////////////////////////////////////////////////////////////    
		if(steering_angle != steering_angle_old) 
		{
		   m_robot_angle_int16.data = steering_angle;
		   m_current_robot_speed_float.data  = motor_speed;
		   //teleop_cmd_vel_pub.publish(teleop_cmd_vel_data) ;
		   //send_serial_data();
		}

		if(motor_speed != motor_speed_old)
		{    
		   m_robot_angle_int16.data = steering_angle;
		   m_current_robot_speed_float.data  = motor_speed;
		   //teleop_cmd_vel_pub.publish(teleop_cmd_vel_data) ;
		   //send_serial_data();
		}
		send_serial_data();
		///////////////////////////////////////////////////////////////////
		steering_angle_old = steering_angle;
		motor_speed_old = motor_speed; 

		//printf("sonar %6.3lf \n",sonar);

		//////////////////// sonar obstacle detectioin //////////////////
		if( ( (sonar[0]>0) && ( sonar[0] <= Sonar_Obstacle_Range ) ) || ( (sonar[1]>0) && ( sonar[1] <= Sonar_Obstacle_Range) ) ||  ( (sonar[2]>0) && ( sonar[2] <= Sonar_Obstacle_Range) ) ) 
		{
		   //motor_speed_cmd  = 0;
		   ROS_INFO("Sonar Obstacle detection : %3.2lf %3.2lf %3.2lf", sonar[0], sonar[1], sonar[2]);       
		}    
		else
		{
			 //motor_speed_cmd = motor_speed;
		} 
		//int ret1=pthread_create(&id_1,NULL,*readserial_thread,NULL);
		//printf("encoder count : %6d\n",m_car_encoder_int.data);
	
		steerangle.data = steering_angle;
		carspeed.data = motor_speed;

		//car_control_pub1.publish(steerangle);
		//car_control_pub2.publish(carspeed);

		//ROS_INFO("Sonar : %5.1lf %5.1lf %5.1lf", sonar[0], sonar[1], sonar[2]);

		//myBaseSensorData.encoder = -(encoder1data + encoder2data) / 2;
		myBaseSensorData.encoder = m_car_encoder_int.data;   //depend on encoder direction
		odometry_cal();
		myBaseSensorData.encoder_old =  myBaseSensorData.encoder;


		//odom_oriention trans to odom_quat
		odom_quat = tf::createQuaternionMsgFromYaw(myOdomCaculateData.oriention);//yaw trans quat

		//pub tf(odom->base_footprint)
		odom_trans.header.stamp = ros::Time::now();
		odom_trans.header.frame_id = odom_frame_id;     
		odom_trans.child_frame_id = odom_child_frame_id;       
		odom_trans.transform.translation.x = myOdomCaculateData.position_x;
		odom_trans.transform.translation.y = myOdomCaculateData.position_y;
		odom_trans.transform.translation.z = 0.0;
		odom_trans.transform.rotation = odom_quat;

		//pub odom
		odom.header.stamp = ros::Time::now(); 
		odom.header.frame_id = odom_frame_id;
		odom.child_frame_id = odom_child_frame_id;       
		odom.pose.pose.position.x = myOdomCaculateData.position_x;     
		odom.pose.pose.position.y = myOdomCaculateData.position_y;
		odom.pose.pose.position.z = 0.0;
		odom.pose.pose.orientation = odom_quat;       
		//odom.twist.twist.linear.x = myOdomCaculateData.velocity_linear;
		//odom.twist.twist.angular.z = myOdomCaculateData.velocity_angular;
		//odom_broadcaster.sendTransform(odom_trans);
		
		odom_pub.publish(odom);
		
		printf("\n\n");

		loop_rate.sleep();
		ros::spinOnce();
		++count;
	}
	motor_speed_cmd = 0;
	steering_angle_cmd = 0;

	return 0;
}



